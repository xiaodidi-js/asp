﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Configuration;

public partial class zhuce1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        OleDbConnection conn = new OleDbConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["acestr"].ToString();
        conn.Open();
        OleDbCommand com = new OleDbCommand();
        com.Connection = conn;
        com.CommandText = "select count(*) from userinfo where uname='" + TextBox1.Text + "'";
        int i = (int)com.ExecuteScalar();
        if (i >= 1)
        {
            Response.Write("<script>alert('用户名已被占用，请选择其他名称')</script>");
            return;
        }
        OleDbCommand insertcom = new OleDbCommand();
        insertcom.Connection = conn;
        insertcom.CommandText = "insert into userinfo(uname,pwd,birth,phone,adress,mail) values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "')";
        int j = insertcom.ExecuteNonQuery();
        Response.Write("<script>alert('注册成功，请点击“返回”进入登陆页面')</script>");
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}