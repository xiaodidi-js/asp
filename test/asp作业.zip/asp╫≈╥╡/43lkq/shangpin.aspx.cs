﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

public partial class Default3 : System.Web.UI.Page
{
    OleDbConnection conn = new OleDbConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        OleDbConnection conn = new OleDbConnection();
        conn.ConnectionString = ConfigurationManager.ConnectionStrings["acestr"].ToString();
        conn.Open();
        OleDbCommand com = new OleDbCommand();
        com.Connection = conn;
        com.CommandText = Session["var1"].ToString();
        GridView1.DataSource = com.ExecuteReader();
        GridView1.DataBind();
        Session.Remove("var1");
    }
}